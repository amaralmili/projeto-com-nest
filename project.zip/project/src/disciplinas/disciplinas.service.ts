import { Injectable } from '@nestjs/common';
import { CreateDisciplinaDto } from './dto/create-disciplina.dto';
import { UpdateDisciplinaDto } from './dto/update-disciplina.dto';
import { Disciplina } from './entities/disciplina.entity';
import { IdGeneratorService } from '../common/id-generator/id-generator.service';

@Injectable()
export class DisciplinasService {
  private disciplinas: Disciplina[] = [];

  constructor(private readonly idGenerator: IdGeneratorService) {}

  create(createDisciplinaDto: CreateDisciplinaDto) :Disciplina{
    const novaDisciplina: Disciplina = {
      id: this.idGenerator.generateId(),
      ...createDisciplinaDto,
    };
    this.disciplinas.push(novaDisciplina);
    console.log(`Disciplina criada: ${JSON.stringify(novaDisciplina)}`);
    return novaDisciplina;
  }

  findAll() {
    return `This action returns all disciplinas`;
  }

  findOne(id: number) {
    return `This action returns a #${id} disciplina`;
  }

  update(id: number, updateDisciplinaDto: UpdateDisciplinaDto) {
    return `This action updates a #${id} disciplina`;
  }

  remove(id: number) {
    return `This action removes a #${id} disciplina`;
  }
}
