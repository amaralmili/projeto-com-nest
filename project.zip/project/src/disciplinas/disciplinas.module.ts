import { Module } from '@nestjs/common';
import { DisciplinasService } from './disciplinas.service';
import { DisciplinasController } from './disciplinas.controller';
import { IdGeneratorService } from 'src/common/id-generator/id-generator.service';

@Module({
  controllers: [DisciplinasController],
  providers: [DisciplinasService, IdGeneratorService],
})
export class DisciplinasModule {}
