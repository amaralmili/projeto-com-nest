export class CreateDisciplinaDto {}
